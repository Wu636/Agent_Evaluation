#!/usr/bin/env node
// Reuse Agent_Evaluation's existing HTTP injection flow, without browser control.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const argv = process.argv.slice(2);
const option = (name, fallback='') => { const i=argv.indexOf(name); return i < 0 ? fallback : argv[i+1]; };
const mode=option('--mode','prepare');
const bundleDir=path.resolve(option('--bundle','.'));
const base=option('--system-url','http://127.0.0.1:3000').replace(/\/$/,'');
const targetInput=option('--target');
const draft=argv.includes('--draft');
const envFile=option('--env-file');
const env={...process.env};
if(envFile){
  for(const line of fs.readFileSync(envFile,'utf8').split(/\r?\n/)){
    const m=line.match(/^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if(!m) continue;
    let v=m[2].trim();
    if((v.startsWith('"')&&v.endsWith('"'))||(v.startsWith("'")&&v.endsWith("'")))v=v.slice(1,-1);
    if(!env[m[1]])env[m[1]]=v;
  }
}
const credentials={authorization:env.POLYMAS_AUTHORIZATION||env.AUTHORIZATION,
  cookie:env.POLYMAS_COOKIE||env.COOKIE,trainSubType:'ability'};
const redact = x => { let s=String(x); for(const secret of [credentials.authorization,credentials.cookie])if(secret)s=s.split(secret).join('[redacted]'); return s; };
const write=(file,value)=>fs.writeFileSync(path.join(bundleDir,file),JSON.stringify(value,null,2)+'\n',{mode:0o600});
const read=file=>JSON.parse(fs.readFileSync(path.join(bundleDir,file),'utf8'));
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');

async function main(){
  if(!['prepare','apply','verify'].includes(mode)||!targetInput)throw Error('使用 --mode prepare|apply|verify --bundle DIR --target URL --env-file FILE');
  if(!credentials.authorization||!credentials.cookie)throw Error('项目保存的登录配置缺少 AUTHORIZATION 或 COOKIE');
  const url=new URL(targetInput);
  if(!/(^|\.)polymas\.com$/i.test(url.hostname)||url.pathname.includes('/language-training/'))throw Error('此适配器用于官方 Polymas 能力训练链接');
  const trainTaskId=url.searchParams.get('trainTaskId');
  const courseId=url.searchParams.get('courseId')||url.searchParams.get('businessId')||url.pathname.match(/\/agent-course-full\/([^/]+)/)?.[1]||'';
  const libraryFolderId=url.searchParams.get('libraryFolderId')||url.searchParams.get('libraryId')||'';
  if(!trainTaskId||!courseId)throw Error('目标链接缺少任务或课程标识');
  const bundle=read('dist/bundle.json');
  const validation=read('validation.json');
  if(!validation.valid)throw Error('请先完成 build 和本地校验');
  const manifest=read('manifest.json');
  if(JSON.stringify(read(manifest.rubricFile))!==JSON.stringify(bundle.scores))throw Error('评分修改后尚未 build');
  for(const [i,file] of manifest.stageFiles.entries()){
    if(JSON.stringify(read(file))!==JSON.stringify(bundle.stages[i]))throw Error('节点修改后尚未 build');
  }
  if(JSON.stringify(manifest)!==JSON.stringify(bundle.manifest))throw Error('规划修改后尚未 build');
  if(hash(fs.readFileSync(path.join(bundleDir,manifest.source.file)))!==manifest.source.sha256)throw Error('来源摘要发生变化');
  const scriptMarkdown=fs.readFileSync(path.join(bundleDir,'dist/训练剧本配置.md'),'utf8');
  const rubricMarkdown=fs.readFileSync(path.join(bundleDir,'dist/评价标准.md'),'utf8');
  const identity={trainTaskId,courseId,libraryFolderId,bundleSha256:bundle.sha256,
    scriptSha256:hash(scriptMarkdown),rubricSha256:hash(rubricMarkdown)};
  const request=async(endpoint,body)=>{
    const response=await fetch(base+endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(45000)});
    if(!response.ok)throw Error(`系统接口 ${endpoint} 返回 HTTP ${response.status}`);
    return response.json();
  };
  const platform=async(name,payload)=>{
    const result=await request('/api/training-inject/proxy',{
      targetUrl:'https://cloudapi.polymas.com/teacher-course/abilityTrain/'+name,payload,credentials});
    if(!(String(result.code)==='200'||result.success===true)){
      const error=new Error(`系统代理 ${name} 返回 ${result.code||'error'}；${result.code===401?'项目保存的登录配置已失效':'请检查平台响应'}`);
      error.platformCode=result.code;throw error;
    }
    return result.data;
  };
  const snapshot=async()=>{
    const result={};
    for(const [key,name] of [['nodes','queryScriptStepList'],['flows','queryScriptStepFlowList'],['scores','queryScoreItemList']]){
      const list=await platform(name,{trainTaskId,...(key==='nodes'?{trainSubType:'ability'}:{})});
      if(!Array.isArray(list))throw Error(`${name} 的数据格式不符，停止后续写入`);
      result[key]=list;
    }
    return result;
  };
  let current=await snapshot();
  const starts=current.nodes.filter(x=>x.stepDetailDTO?.nodeType==='SCRIPT_START');
  const ends=current.nodes.filter(x=>x.stepDetailDTO?.nodeType==='SCRIPT_END');
  if(starts.length!==1||ends.length!==1)throw Error('目标尚未初始化唯一 START/END');
  const business=current.nodes.filter(x=>!['SCRIPT_START','SCRIPT_END'].includes(x.stepDetailDTO?.nodeType));
  write('system-target-preflight.json',{...identity,source:'existing system interfaces',snapshot:current});
  console.log(JSON.stringify({phase:'preflight',nodes:business.length,flows:current.flows.length,scores:current.scores.length}));
  if(mode==='prepare')return;
  const verify=()=>{
    const errors=[];
    if(current.nodes.length!==bundle.stages.length+2)errors.push('节点总数不符');
    const ids=new Map([['START',starts[0].stepId],['END',ends[0].stepId]]);
    for(const stage of bundle.stages){
      const matches=current.nodes.filter(x=>x.stepDetailDTO?.stepName===stage.name);
      if(matches.length!==1){errors.push(`节点缺失或重复：${stage.id}`);continue;}
      ids.set(stage.id,matches[0].stepId);
      const actual=matches[0].stepDetailDTO;
      const expected={prologue:stage.prologue,llmPrompt:manifest.sharedPrompt.trim()+'\n\n'+stage.prompt.trim(),interactiveRounds:stage.rounds};
      for(const [key,value] of Object.entries(expected))if(String(actual[key])!==String(value))errors.push(`${stage.id} 字段不符：${key}`);
      if(String(actual.isSkipStep)!=='0')errors.push(`${stage.id} 跳过开关未关闭`);
    }
    if(current.flows.length!==manifest.edges.length)errors.push('连线数不符');
    for(const edge of manifest.edges){
      const matches=current.flows.filter(x=>x.scriptStepStartId===ids.get(edge.from)&&x.scriptStepEndId===ids.get(edge.to)&&String(x.flowCondition||'')===edge.condition);
      if(matches.length!==1)errors.push(`连线缺失或重复：${edge.from} → ${edge.to}`);
      else if(edge.from!=='START'&&String(matches[0].isDefault)!=='0')errors.push(`条件边被设为默认：${edge.from}`);
    }
    if(current.scores.length!==bundle.scores.length)errors.push('评分项数不符');
    for(const item of bundle.scores){
      const matches=current.scores.filter(x=>x.itemName===item.itemName&&Number(x.score)===item.score);
      if(matches.length!==1){errors.push(`评分项缺失或重复：${item.itemName}`);continue;}
      const detail=String(matches[0].requireDetail||'').replace(/\s/g,'');
      for(const child of item.children||[])if(!detail.includes(child.requirement.replace(/\s/g,'')))errors.push(`评分细目缺失：${child.name}`);
    }
    const report={...identity,verified:errors.length===0,errors,nodes:current.nodes.filter(x=>x.stepDetailDTO?.nodeType==='SCRIPT_NODE').length,flows:current.flows.length,scores:current.scores.length,
      draft,studentRuntimeTest:'待实际学生端验证'};
    write('system-verification.json',report);
    if(errors.length)throw Error('回采校验发现差异，详见 system-verification.json');
    console.log(JSON.stringify(report));
  };
  if(mode==='verify'){
    write('system-target-readback.json',{...identity,snapshot:current});
    verify();
    const statePath=path.join(bundleDir,'system-injection-state.json');
    if(fs.existsSync(statePath)){
      const previous=read('system-injection-state.json');
      if(previous.trainTaskId===trainTaskId&&previous.bundleSha256===bundle.sha256)
        write('system-injection-state.json',{...identity,status:'configuration_verified',draft});
    }
    return;
  }
  if(business.length||current.scores.length)throw Error('目标已有业务节点或评分项；先回采核对，避免替换或重复创建');
  if(current.flows.some(x=>x.scriptStepStartId!==starts[0].stepId||x.scriptStepEndId!==ends[0].stepId))throw Error('空目标存在其他连线');
  if(bundle.reviewIssues.some(x=>x.status!=='resolved')&&!draft)throw Error('教师内容待核对；保存原文教师编辑稿时须显式指定 --draft');
  write('system-target-backup.json',{...identity,snapshot:current});
  const events=[];
  write('system-injection-state.json',{...identity,status:'started',draft});
  const response=await fetch(base+'/api/training-inject',{method:'POST',headers:{'Content-Type':'application/json','Accept':'text/event-stream'},
    body:JSON.stringify({trainTaskId,courseId,libraryFolderId,credentials,scriptMarkdown,rubricMarkdown,extractionMode:'regex',injectMode:'replace',
      injectCoverImage:false,injectBackgroundImage:false,injectDigitalHuman:false}),signal:AbortSignal.timeout(600000)});
  if(!response.ok||!response.body)throw Error(`系统注入接口 HTTP ${response.status}`);
  let buffer='',complete=false;
  const decoder=new TextDecoder();
  for await(const chunk of response.body){
    buffer+=decoder.decode(chunk,{stream:true});
    let boundary;
    while((boundary=buffer.indexOf('\n\n'))>=0){
      const frame=buffer.slice(0,boundary);buffer=buffer.slice(boundary+2);
      const line=frame.split('\n').find(x=>x.startsWith('data: '));if(!line)continue;
      const event=JSON.parse(line.slice(6));events.push(event);write('system-injection-events.json',events);
      console.log(redact(JSON.stringify(event)));
      if(event.type==='error')throw Error('系统注入报告错误；先回采现状，不自动重做替换');
      if(event.type==='complete')complete=true;
    }
  }
  if(!complete)throw Error('注入连接结束，但未收到完成事件；先回采现状');
  current=await snapshot();
  // Preserve every server field while closing the per-card skip switch.
  for(const node of current.nodes.filter(x=>x.stepDetailDTO?.nodeType==='SCRIPT_NODE')){
    if(String(node.stepDetailDTO.isSkipStep)==='0')continue;
    await platform('editScriptStep',{trainTaskId,courseId,libraryFolderId,stepId:node.stepId,
      stepDetailDTO:{...node.stepDetailDTO,isSkipStep:0},positionDTO:node.positionDTO});
  }
  current=await snapshot();
  write('system-target-readback.json',{...identity,snapshot:current});
  verify();
  write('system-injection-state.json',{...identity,status:'configuration_verified',draft});
}
main().catch(error=>{
  write('system-last-error.json',{mode,error:redact(error.message),platformCode:error.platformCode,writeAttempted:fs.existsSync(path.join(bundleDir,'system-injection-state.json'))});
  console.error(redact(error.message));process.exitCode=1;
});
