# 工作目录格式

`init` 会完整复制来源并生成摄取分片。随后由 agent 写入以下数据；脚本不会自行理解文档或调用模型。

```json
{
  "schemaVersion": 1,
  "taskName": "案例名称",
  "audience": "目标学生",
  "description": "教学目标",
  "source": {"file": "source.txt", "sha256": "init 记录的摘要"},
  "sharedPrompt": "人设、角色锁定、跨节点状态、通用边界",
  "stageFiles": ["stages/01.json", "stages/02.json"],
  "edges": [
    {"from": "START", "to": "CHOOSE", "condition": ""},
    {"from": "CHOOSE", "to": "FINISH", "condition": "NEXT_TO_FINISH"},
    {"from": "FINISH", "to": "END", "condition": "TASK_COMPLETE"}
  ],
  "requirements": [
    {"id": "R01", "sourceFile": "source.txt", "quote": "来源中逐字存在的要求",
     "checks": [{"stage": "FINISH", "field": "prologue", "contains": "必须原样出现的内容"}]}
  ],
  "totalScore": 100,
  "rubricFile": "rubric.json",
  "reviewIssuesFile": "review-issues.json"
}
```

节点 JSON 必填 `id`、`name`、`teacherPhase`、`kind`、`trainerName`、`description`、`prologue`、`prompt`、`rounds`。`kind` 可为 `interaction`、`summary`、`closure`。可选 `literalSummary` 指定必须逐字出现在该节点开场白中的小结；`futureForbidden` 指定本节点开场白和最终提示词中禁止出现的后续线索。`rounds` 是平台配置值，不能证明运行时门控；采用明确正整数。

`transitionPrompt` 设置在出边：建议使用“逐字输出下一阶段原始开场白 ${next_stage_opening}，保留小结，不自行添加后续线索”。每个同起点出边的 condition 必须唯一且在对应 prompt 中存在。首尾特殊值为 START/END。每个阶段均须从 START 可达且可到达 END。

`rubric.json` 为数组，每项含 `itemName`、`score`、`description`、`requireDetail`；可带 `children: [{name, score, requirement}]`，子项之和必须等于该项分数。评分内容注入为 requireDetail，children 编译时一并附加。

导出的评分 Markdown 使用当前系统明确支持的 `**评价描述：**` 和 `**评分区间：**` 分隔。仅以“得分点”标题分段时，旧解析路径会把全部细目放入 description，而 requireDetail 为空。验收必须同时检查分值和 requireDetail 的具体子项，不能只检查评分项数量。

`review-issues.json` 是数组，每项含 `id`、`status`（open/resolved）、`quote`、`issue`、`suggestion`、`sources`。解决问题须实际修订教师确认后的节点/评分文本并更新覆盖索引；只改状态不构成医学内容审核。

输出 `dist/训练剧本配置.md`、`dist/评价标准.md`、`dist/bundle.json`、`validation.json`。继续编辑 stages 后重新 build；检查点已开始注入时内容散列变化会阻止续跑，避免把两版配置混入一次操作。
