#!/usr/bin/env python3
"""Local-first training bundle compiler and resumable Polymas adapter; stdlib only."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import sys
import urllib.error
import urllib.parse
import urllib.request


def digest(value):
    raw = value if isinstance(value, bytes) else json.dumps(value, ensure_ascii=False, sort_keys=True).encode()
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temp.chmod(0o600)
    temp.replace(path)


def inside(root, relative):
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("文件路径超出工作目录")
    return path


def initialize(source, out):
    out = Path(out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    if (out / "source.txt").exists() or (out / "manifest.json").exists():
        raise ValueError("目标已有来源或配置，请沿用现有工作目录或选择新目录")
    raw = Path(source).read_bytes()
    content = raw.decode("utf-8-sig")
    if not content.strip():
        raise ValueError("来源文档为空")
    (out / "source.txt").write_text(content, encoding="utf-8")
    # Preserve every character; cut at newline where possible, never discard the tail.
    pieces = []
    start = 0
    while start < len(content):
        end = min(start + 7000, len(content))
        if end < len(content):
            boundary = content.rfind("\n", start + 1000, end)
            if boundary > start:
                end = boundary + 1
        part = content[start:end]
        name = f"source-parts/{len(pieces) + 1:03}.txt"
        inside(out, name).parent.mkdir(exist_ok=True)
        inside(out, name).write_text(part, encoding="utf-8")
        pieces.append({"file": name, "startChar": start, "endChar": end, "sha256": digest(part.encode())})
        start = end
    source_info = {"file": "source.txt", "sha256": digest(content.encode())}
    save(out / "source-map.json", {"source": source_info, "characters": len(content), "parts": pieces})
    save(out / "manifest.json", {"schemaVersion": 1, "taskName": "", "audience": "", "description": "",
        "source": source_info, "sharedPrompt": "", "stageFiles": [], "edges": [], "requirements": [],
        "totalScore": 100, "rubricFile": "rubric.json", "reviewIssuesFile": "review-issues.json"})
    save(out / "rubric.json", [])
    save(out / "review-issues.json", [])
    return {"initialized": str(out), "characters": len(content), "parts": len(pieces)}


def load_bundle(root):
    root = Path(root).resolve()
    manifest = read(root / "manifest.json")
    stages = [read(inside(root, name)) for name in manifest["stageFiles"]]
    scores = read(inside(root, manifest["rubricFile"]))
    issues = read(inside(root, manifest["reviewIssuesFile"]))
    return manifest, stages, scores, issues


def compile_prompt(manifest, stage):
    return manifest["sharedPrompt"].strip() + "\n\n" + stage["prompt"].strip()


def validate(root):
    root = Path(root).resolve()
    errors, warnings, coverage = [], [], []
    try:
        m, stages, scores, issues = load_bundle(root)
        for field in ("taskName", "audience", "description", "sharedPrompt"):
            if not str(m.get(field, "")).strip():
                errors.append(f"缺少 {field}")
        source = inside(root, m["source"]["file"]).read_bytes()
        if digest(source) != m["source"]["sha256"]:
            errors.append("来源摘要发生变化，请重新核对来源索引")
        if m.get("schemaVersion") != 1:
            errors.append("schemaVersion 应为 1")
        ids = [s["id"] for s in stages]
        if not ids or len(set(ids)) != len(ids) or {"START", "END"}.intersection(ids):
            errors.append("节点为空、ID 重复或占用 START/END")
        by_id = {s["id"]: s for s in stages}
        for s in stages:
            for field in ("id", "name", "teacherPhase", "kind", "trainerName", "description", "prologue", "prompt"):
                if not str(s.get(field, "")).strip():
                    errors.append(f"{s.get('id')} 缺少 {field}")
            if not isinstance(s.get("rounds"), int) or isinstance(s.get("rounds"), bool) or s["rounds"] < 1:
                errors.append(f"{s['id']} 轮次须为正整数")
            if s.get("literalSummary") and s["literalSummary"] not in s["prologue"]:
                errors.append(f"{s['id']} 原文小结未逐字出现在开场白")
            combined = s["prologue"] + compile_prompt(m, s)
            if "```" in combined:
                errors.append(f"{s['id']} 提示词含嵌套代码围栏，请使用行内标记")
            for forbidden in s.get("futureForbidden", []):
                if forbidden in combined:
                    errors.append(f"{s['id']} 提前出现后续线索：{forbidden}")
        edges = m["edges"]
        adjacency, reverse, seen = {}, {}, set()
        for e in edges:
            a, b, condition = e["from"], e["to"], e["condition"]
            if a not in {*ids, "START"} or b not in {*ids, "END"} or a == b:
                errors.append(f"连线端点错误：{a} → {b}")
            if (a, condition) in seen:
                errors.append(f"同一起点条件重复：{a} {condition}")
            seen.add((a, condition))
            if a != "START":
                if not re.fullmatch(r"NEXT_TO_[A-Z0-9_]+|TASK_COMPLETE", condition):
                    errors.append(f"跳转词格式错误：{condition}")
                if a in by_id and condition not in by_id[a]["prompt"]:
                    errors.append(f"{a} 提示词缺少跳转词 {condition}")
                if b == "END" and condition != "TASK_COMPLETE":
                    errors.append(f"{a} 结束边应为 TASK_COMPLETE")
            adjacency.setdefault(a, []).append(b)
            reverse.setdefault(b, []).append(a)
        def walk(start, graph):
            found, todo = set(), [start]
            while todo:
                node = todo.pop()
                if node not in found:
                    found.add(node)
                    todo.extend(graph.get(node, []))
            return found
        if len(adjacency.get("START", [])) != 1:
            errors.append("START 须有一个明确入口")
        if set(ids) - walk("START", adjacency):
            errors.append("存在从 START 不可达的节点")
        if set(ids) - walk("END", reverse):
            errors.append("存在没有结束路径的节点")
        for req in m.get("requirements", []):
            quote = req.get("quote", "")
            quoted_source = inside(root, req.get("sourceFile", m["source"]["file"])).read_text(encoding="utf-8")
            ok = bool(quote) and quote in quoted_source and bool(req.get("checks"))
            for check in req.get("checks", []):
                stage = by_id.get(check["stage"], {})
                field = check["field"]
                value = compile_prompt(m, stage) if field == "compiledPrompt" and stage else stage.get(field, "")
                ok = ok and bool(check.get("contains")) and check["contains"] in str(value)
            coverage.append({"id": req["id"], "passed": bool(ok)})
            if not ok:
                errors.append(f"来源或落点覆盖失败：{req['id']}")
        if not coverage:
            errors.append("缺少来源覆盖要求")
        if not scores or sum(x["score"] for x in scores) != m["totalScore"]:
            errors.append("评分项合计与教师总分不符")
        if len({x["itemName"] for x in scores}) != len(scores):
            errors.append("评分项名称重复")
        for x in scores:
            if not all(x.get(k) for k in ("itemName", "description", "requireDetail")) or x["score"] <= 0:
                errors.append("评分项字段缺失或分数非正")
            if x.get("children") and sum(y["score"] for y in x["children"]) != x["score"]:
                errors.append(f"{x['itemName']} 子项合计错误")
        open_issues = [x for x in issues if x.get("status") != "resolved"]
        if open_issues:
            warnings.append(f"教师内容待核对 {len(open_issues)} 项；当前为审核稿")
        warnings.append("学生端跨节点历史、条件跳转和最大轮次行为待实际验证")
    except (KeyError, TypeError, ValueError, OSError) as exc:
        errors.append(f"配置读取或结构错误：{exc}")
    report = {"valid": not errors, "errors": errors, "warnings": warnings, "coverage": coverage,
              "coverageCount": len(coverage), "stageCount": len(stages) if 'stages' in locals() else 0,
              "semanticReview": "需 agent 逐情景复核；本报告只检查结构与文本覆盖"}
    save(root / "validation.json", report)
    return report


def score_detail(item):
    children = "\n".join(f"{i + 1}. {c['name']}（{c['score']}分）：{c['requirement']}" for i, c in enumerate(item.get("children", [])))
    return item["requireDetail"] + ("\n" + children if children else "")


def build(root):
    root = Path(root).resolve()
    report = validate(root)
    if not report["valid"]:
        raise ValueError("配置校验未通过：" + "；".join(report["errors"]))
    m, stages, scores, issues = load_bundle(root)
    bundle = {"manifest": m, "stages": stages, "scores": scores, "reviewIssues": issues}
    bundle["sha256"] = digest(bundle)
    dist = root / "dist"
    dist.mkdir(exist_ok=True)
    save(dist / "bundle.json", bundle)
    plan = {"taskName": m["taskName"], "audience": m["audience"], "overallObjective": m["description"],
            "recommendedMode": "general", "flowType": "graph", "modules": [], "edges": [], "notes": m.get("notes", [])}
    for s in stages:
        plan["modules"].append({"id": s["id"], "title": s["name"], "moduleType": "summary" if s["kind"] in ("summary", "closure") else "general",
            "objective": s["description"], "description": s["description"], "keyPoints": [s["description"]],
            "interactionStyle": "累积检查、启发追问" if s["kind"] == "interaction" else "完整展示、阅读确认",
            "transitionGoal": "完成当前环节后按显式条件进入下一环节", "suggestedRounds": s["rounds"]})
    for i, e in enumerate(m["edges"]):
        if e["from"] != "START":
            plan["edges"].append({"id": f"edge-{i}", "fromModuleId": e["from"], "toModuleId": "__END__" if e["to"] == "END" else e["to"],
                "condition": e["condition"], "conditionDescription": "本节点任务完成并满足继续条件", "transitionPrompt": e.get("transitionPrompt", ""), "isDefault": 0})
    save(dist / "智能规划.json", plan)
    lines = [f"# {m['taskName']} - 训练剧本配置", "", "## 📋 基础配置", "",
             f"- **任务名称**: {m['taskName']}", f"- **任务描述**: {m['description']}",
             f"- **目标受众**: {m['audience']}", f"- **智能体角色**: {stages[0]['trainerName']}（以各节点 Role 配置为准）", "", "## 📝 训练阶段", ""]
    for i, s in enumerate(stages, 1):
        outgoing = [e for e in m["edges"] if e["from"] == s["id"]]
        transition = outgoing[0].get("transitionPrompt", "逐字输出下一阶段原始开场白 ${next_stage_opening}，保留原文小结。") if outgoing else ""
        lines += [f"### 阶段{i}: {s['name']}", "", f"**虚拟训练官名字**: {s['trainerName']}",
                  "**模型**: (选填，默认为空)", "**声音**: (选填，默认为空)", "**形象**: (选填，默认为空)",
                  f"**阶段描述**: {s['description']}", "**背景图**: (选填，默认为空)",
                  f"**互动轮次**: {s['rounds']}轮", f"**flowCondition**: \"{outgoing[0]['condition'] if outgoing else ''}\"", ""]
        for label, text_value in (("transitionPrompt", transition), ("开场白", s["prologue"]), ("提示词", compile_prompt(m, s))):
            lines += [f"**{label}**:", "```", text_value, "```", ""]
    names = {s["id"]: f"阶段{i}" for i, s in enumerate(stages, 1)} | {"START": "START", "END": "END"}
    graph = {"flowType": "graph", "edges": [{**e, "from": names[e["from"]], "to": names[e["to"]],
              "isDefault": 0} for e in m["edges"] if e["from"] != "START"]}
    lines += ["## 🔀 非线性跳转关系", "", "```json", json.dumps(graph, ensure_ascii=False, indent=2), "```", "",
              "## 配置说明", "", "原教师教学阶段保留；小结与收尾拆成输出卡片，以保证逐字展示。START 唯一入口由现有注入器自动连接；上方 JSON 仅列教学节点之间及到 END 的条件边。", "",
              "本文为配置审核稿；待核对条目见工作目录 review-issues.json。结构校验通过不等于学生端行为实测通过。", ""]
    (dist / "训练剧本配置.md").write_text("\n".join(lines), encoding="utf-8")
    rubric = [f"# {m['taskName']} - 评价标准", "", f"## 总分：{m['totalScore']}分", "",
              "保留教师主维度及分值。子得分点分配为生成建议；基于本次实际作答评分，选做未做计零分。", ""]
    for item in scores:
        rubric += [f"## {item['itemName']}({item['score']}分)", "", "**评价描述：**", item["description"], "", "**评分区间：**", score_detail(item), ""]
    (dist / "评价标准.md").write_text("\n".join(rubric), encoding="utf-8")
    return {"built": str(dist), "sha256": bundle["sha256"], "stages": len(stages), "flows": len(m["edges"]), "scoreItems": len(scores), "warnings": report["warnings"]}


class Platform:
    def __init__(self, api_root, timeout):
        parsed = urllib.parse.urlparse(api_root)
        if parsed.scheme != "https" and not (parsed.scheme == "http" and parsed.hostname in ("127.0.0.1", "localhost", "::1")):
            raise ValueError("正式 API 地址须使用 HTTPS；HTTP 仅用于本机测试")
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("API 地址应仅含服务根路径")
        self.base = api_root.rstrip("/") + "/teacher-course/abilityTrain/"
        self.timeout = timeout
        authorization, cookie = os.getenv("POLYMAS_AUTHORIZATION"), os.getenv("POLYMAS_COOKIE")
        if not authorization or not cookie:
            raise ValueError("请在当前进程环境设置平台登录凭证")
        self.headers = {"Content-Type": "application/json; charset=utf-8", "Authorization": authorization,
                        "Cookie": cookie, "User-Agent": "Mozilla/5.0 TrainingConfigAgent"}
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, msg, headers, newurl):
                return None
        handlers = [NoRedirect()]
        if parsed.hostname in ("127.0.0.1", "localhost", "::1"):
            handlers.append(urllib.request.ProxyHandler({}))
        self.opener = urllib.request.build_opener(*handlers)

    def post(self, endpoint, payload):
        request = urllib.request.Request(self.base + endpoint, data=json.dumps(payload, ensure_ascii=False).encode(), headers=self.headers, method="POST")
        # Never print response text: upstream errors may echo sensitive headers.
        try:
            with self.opener.open(request, timeout=self.timeout) as response:
                result = json.load(response)
        except urllib.error.HTTPError as exc:
            code = exc.code
            exc.close()
            raise RuntimeError(f"{endpoint}: HTTP {code}，保留检查点；先回采再续跑") from None
        except (urllib.error.URLError, TimeoutError, ValueError) as exc:
            raise RuntimeError(f"{endpoint}: 网络或响应异常（{type(exc).__name__}），保留检查点；先回采再续跑") from None
        if not isinstance(result, dict) or not (str(result.get("code")) == "200" or result.get("success") is True):
            raise RuntimeError(f"{endpoint}: 平台未确认成功，保留检查点")
        return result.get("data")

    def snapshot(self, task):
        values = {}
        for key, endpoint in (("nodes", "queryScriptStepList"), ("flows", "queryScriptStepFlowList"), ("scores", "queryScoreItemList")):
            value = self.post(endpoint, {"trainTaskId": task, **({"trainSubType": "ability"} if key == "nodes" else {})})
            if not isinstance(value, list):
                raise RuntimeError(f"{endpoint}: data 应为列表，停止写入")
            values[key] = value
        return values


def target_info(target, course, library):
    if target.startswith(("https://", "http://")):
        url = urllib.parse.urlparse(target)
        if "/language-training/" in url.path:
            raise ValueError("此适配器仅处理能力训练")
        q = urllib.parse.parse_qs(url.query)
        get = lambda *keys: next((q[k][0] for k in keys if q.get(k)), "")
        match = re.search(r"/agent-course-full/([^/]+)", url.path)
        task = get("trainTaskId")
        course = course or get("courseId", "businessId") or (match[1] if match else "")
        library = library or get("libraryFolderId", "libraryId")
    else:
        task = target
    if not task or len(task) > 100 or not re.fullmatch(r"[A-Za-z0-9_-]+", task):
        raise ValueError("请提供含 trainTaskId 的完整链接或有效任务 ID")
    return {"task": task, "course": course, "library": library}


def make_id():
    return "".join(secrets.choice("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_-") for _ in range(21))


def detail(m, stage):
    return {"nodeType": "SCRIPT_NODE", "stepName": stage["name"], "trainerName": stage["trainerName"],
        "description": stage["description"], "prologue": stage["prologue"], "llmPrompt": compile_prompt(m, stage),
        "modelId": os.getenv("POLYMAS_MODEL_ID", "Doubao-Seed-2.0-pro"), "interactiveRounds": stage["rounds"],
        "isSkipStep": 0, "endStrategy": 2, "contentSkip": 0, "historyRecordNum": -1, "isTransition": 0,
        "agentId": os.getenv("POLYMAS_AGENT_ID", "Tg3LpKo28D"),
        "agentVoiceId": os.getenv("POLYMAS_AGENT_VOICE_ID", "zh_male_qingcang_mars_bigtts"),
        "avatarNid": "", "customDigitalHuman": None, "digitalHumanType": None,
        "backgroundTheme": None, "scriptBackgroundType": "image", "scriptStepCover": {},
        "scriptStepResourceList": [], "knowledgeBaseId": "", "knowledgeBaseSwitch": 1,
        "knowledgeResourceList": [], "searchEngineSwitch": 1, "projectId": "", "refResourceDesc": 0,
        "whiteBoardSwitch": 0, "videoSwitch": 0, "trainSubType": "ability",
        "stepExtProperty": {"trainSubType": "ability", "resources": [{"nid": "", "category": "未分类", "list": []}],
            "bgMediaType": 1, "bgMediaVolume": 80, "bgMusic": {}, "bgMusicVolume": 30,
            "transitionBgMedia": None, "transitionBgMediaType": 1, "transitionBgMediaVolume": 30,
            "useTransitionBgMediaTransition": 0, "transitionBgMusic": None, "transitionBgMusicVolume": 30,
            "flowAsideContent": "", "flowAsideVoiceType": None, "flowAsideVoiceNid": None,
            "flowAsideVoiceSpeed": 50, "flowAsideVoiceVolume": 30, "flowAsideMp3Url": "", "hideSubtitle": 0, "useAsideTransition": 0}}


def normalized_score(x):
    return {"itemName": x.get("itemName", x.get("name", "")), "score": float(x.get("score", x.get("itemScore", 0))),
            "description": x.get("description", ""), "requireDetail": x.get("requireDetail", x.get("requirement", ""))}


def expected_score(x):
    return {"itemName": x["itemName"], "score": x["score"], "description": x["description"], "requireDetail": score_detail(x)}


def check_owned(snapshot, state):
    owned = {v["id"] for v in state.get("nodes", {}).values()}
    unexpected = [n for n in snapshot["nodes"] if n.get("stepDetailDTO", {}).get("nodeType") == "SCRIPT_NODE" and n["stepId"] not in owned]
    if unexpected:
        raise ValueError("目标已有其他业务节点；本工具只向空目标或本次检查点写入")
    unexpected_types = [n for n in snapshot["nodes"] if n.get("stepDetailDTO", {}).get("nodeType") not in ("SCRIPT_START", "SCRIPT_END", "SCRIPT_NODE")]
    if unexpected_types:
        raise ValueError("目标存在未知类型节点，请先核对")
    starts = [n["stepId"] for n in snapshot["nodes"] if n["stepDetailDTO"]["nodeType"] == "SCRIPT_START"]
    ends = [n["stepId"] for n in snapshot["nodes"] if n["stepDetailDTO"]["nodeType"] == "SCRIPT_END"]
    if len(starts) != 1 or len(ends) != 1:
        raise ValueError("请先在平台工作流编辑页初始化唯一 START/END")
    owned_flows = {v["id"] for v in state.get("flows", {}).values()}
    for f in snapshot["flows"]:
        empty_link = f["scriptStepStartId"] == starts[0] and f["scriptStepEndId"] == ends[0]
        if f["flowId"] not in owned_flows and not empty_link:
            raise ValueError("目标存在本次检查点以外的连线")
    return starts[0], ends[0]


def verify_snapshot(snapshot, bundle, state):
    errors = []
    m = bundle["manifest"]
    by_id = {n["stepId"]: n for n in snapshot["nodes"]}
    check_owned(snapshot, state)
    for s in bundle["stages"]:
        nid = state.get("nodes", {}).get(s["id"], {}).get("id")
        actual = by_id.get(nid, {}).get("stepDetailDTO", {})
        expected = detail(m, s)
        for key in ("stepName", "prologue", "llmPrompt", "interactiveRounds", "isSkipStep", "historyRecordNum", "endStrategy"):
            if str(actual.get(key)) != str(expected[key]):
                errors.append(f"{s['id']} 字段不符：{key}")
    actual_flows = {f["flowId"]: f for f in snapshot["flows"]}
    for key, f in state.get("flows", {}).items():
        actual = actual_flows.get(f["id"], {})
        for field in ("scriptStepStartId", "scriptStepEndId", "flowCondition", "transitionPrompt", "isDefault"):
            if str(actual.get(field)) != str(f["payload"][field]):
                errors.append(f"连线 {key} 字段不符：{field}")
    if len(actual_flows) != len(m["edges"]) or len(state.get("flows", {})) != len(m["edges"]):
        errors.append("回采连线数量不符")
    for item in bundle["scores"]:
        matched = [x for x in snapshot["scores"] if normalized_score(x)["itemName"] == item["itemName"]]
        if len(matched) != 1 or normalized_score(matched[0]) != expected_score(item):
            errors.append(f"评分项不符或重复：{item['itemName']}")
    if len(snapshot["scores"]) != len(bundle["scores"]):
        errors.append("目标评分项数量不符")
    return {"verified": not errors, "errors": errors, "nodes": len(bundle["stages"]), "flows": len(actual_flows),
            "scores": len(snapshot["scores"]), "studentRuntimeTest": "待实际平台学生端实测"}


def platform_action(args):
    root = Path(args.bundle).resolve()
    build(root)
    bundle = read(root / "dist/bundle.json")
    target = target_info(args.target, args.course_id, args.library_id)
    platform = Platform(args.api_root, args.timeout)
    state_path = root / "injection-state.json"
    state = read(state_path) if state_path.exists() else {"bundleSha256": bundle["sha256"], "apiRoot": args.api_root.rstrip("/"),
        "target": target, "nodes": {}, "flows": {}, "scores": {}, "status": "prepared"}
    if state["bundleSha256"] != bundle["sha256"] or state["target"] != target or state["apiRoot"] != args.api_root.rstrip("/"):
        raise ValueError("内容或目标与检查点不符；请使用原版本续跑，或为新目标准备独立工作目录")
    snapshot = platform.snapshot(target["task"])
    start, end = check_owned(snapshot, state)
    expected_scores = {i["itemName"]: expected_score(i) for i in bundle["scores"]}
    for item in snapshot["scores"]:
        normal = normalized_score(item)
        if normal != expected_scores.get(normal["itemName"]):
            raise ValueError("目标已有不同评分标准，请使用空训练任务")
    if args.command == "verify":
        if not state_path.exists():
            raise ValueError("尚无注入检查点")
        report = verify_snapshot(snapshot, bundle, state)
        save(root / "verification.json", report)
        if not report["verified"]:
            raise ValueError("回采校验未通过：" + "；".join(report["errors"]))
        return report
    if args.command == "prepare":
        save(root / "target-preview.json", {"target": target, "apiRoot": args.api_root, "snapshot": snapshot,
            "planned": {"stages": len(bundle["stages"]), "flows": len(bundle["manifest"]["edges"]), "scores": len(bundle["scores"])}})
        return {"ready": True, "readOnly": True, "contentReviewOpen": sum(i.get("status") != "resolved" for i in bundle["reviewIssues"])}
    if any(i.get("status") != "resolved" for i in bundle["reviewIssues"]):
        raise ValueError("教师内容仍有待核对项，请先完成内容审核并更新配置")
    # Lock only the mutating operation. Atomic state writes precede each network mutation.
    lock = root / "injection.lock"
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        raise ValueError("检测到注入锁；先确认上一次进程已结束，再移除遗留锁") from None
    try:
        os.close(fd)
        if not (root / "target-backup.json").exists():
            save(root / "target-backup.json", snapshot)
        save(state_path, state)
        task = target["task"]
        known = {n["stepId"] for n in snapshot["nodes"]}
        ids = {"START": start, "END": end}
        for index, s in enumerate(bundle["stages"]):
            record = state["nodes"].setdefault(s["id"], {"id": make_id(), "status": "planned"})
            save(state_path, state)
            payload = {"trainTaskId": task, "stepId": record["id"], "stepDetailDTO": detail(bundle["manifest"], s),
                       "positionDTO": {"x": 300 + index * 430, "y": 300}}
            if record["id"] not in known:
                record["status"] = "creating"
                save(state_path, state)
                platform.post("createScriptStep", payload)
            record["status"] = "editing"
            save(state_path, state)
            platform.post("editScriptStep", {**payload, "courseId": target["course"], "libraryFolderId": target["library"]})
            record["status"] = "done"
            ids[s["id"]] = record["id"]
            save(state_path, state)
            print(json.dumps({"node": s["id"], "status": "saved"}, ensure_ascii=False), flush=True)
        # Create all non-entry edges first. Create START last, after removing empty bypass.
        edges = sorted(bundle["manifest"]["edges"], key=lambda e: e["from"] == "START")
        live_flows = {f["flowId"] for f in platform.snapshot(task)["flows"]}
        for e in edges:
            if e["from"] == "START":
                for old in platform.snapshot(task)["flows"]:
                    if old["scriptStepStartId"] == start and old["scriptStepEndId"] == end:
                        platform.post("delScriptStepFlow", {"trainTaskId": task, "flowId": old["flowId"]})
            key = f"{e['from']}|{e['condition']}|{e['to']}"
            record = state["flows"].setdefault(key, {"id": make_id(), "status": "planned"})
            a, b = ids[e["from"]], ids[e["to"]]
            payload = {"trainTaskId": task, "flowId": record["id"], "scriptStepStartId": a,
                "scriptStepStartHandle": a + "-source-bottom", "scriptStepEndId": b, "scriptStepEndHandle": b + "-target-top",
                "flowSettingType": "quick", "flowCondition": e["condition"],
                "flowConfiguration": {"relation": "and", "conditions": [{"text": "条件组1", "relation": "and", "conditions": [{"text": e["condition"]}]}]},
                "transitionPrompt": e.get("transitionPrompt", ""), "transitionHistoryNum": -1,
                "isDefault": 1 if e["from"] == "START" else 0, "isError": False}
            record["payload"] = payload
            save(state_path, state)
            if record["id"] not in live_flows:
                platform.post("createScriptStepFlow", payload)
            record["status"] = "done"
            save(state_path, state)
        for item in bundle["scores"]:
            expected = expected_score(item)
            live = platform.snapshot(task)["scores"]
            matches = [x for x in live if normalized_score(x)["itemName"] == item["itemName"]]
            if matches and (len(matches) != 1 or normalized_score(matches[0]) != expected):
                raise ValueError("评分名称冲突，停止写入")
            state["scores"][item["itemName"]] = "creating" if not matches else "done"
            save(state_path, state)
            if not matches:
                platform.post("createScoreItem", {"trainTaskId": task, **expected})
            state["scores"][item["itemName"]] = "done"
            save(state_path, state)
        report = verify_snapshot(platform.snapshot(task), bundle, state)
        save(root / "verification.json", report)
        if not report["verified"]:
            raise ValueError("回采发现配置不符，请检查 verification.json 后续跑")
        state["status"] = "configuration_verified"
        save(state_path, state)
        return report
    finally:
        lock.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init")
    init.add_argument("--source", required=True)
    init.add_argument("--out", required=True)
    for command in ("validate", "build", "prepare", "apply", "verify"):
        p = sub.add_parser(command)
        p.add_argument("--bundle", required=True)
        if command in ("prepare", "apply", "verify"):
            p.add_argument("--target", required=True)
            p.add_argument("--course-id", default="")
            p.add_argument("--library-id", default="")
            p.add_argument("--api-root", default="https://cloudapi.polymas.com")
            p.add_argument("--timeout", type=float, default=45)
    args = parser.parse_args()
    try:
        if args.command == "init":
            result = initialize(args.source, args.out)
        elif args.command == "validate":
            result = validate(args.bundle)
        elif args.command == "build":
            result = build(args.bundle)
        else:
            result = platform_action(args)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get("valid", True) else 1
    except (ValueError, RuntimeError, OSError, KeyError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
