# Polymas 能力训练适配

## 当前系统入口（优先）

`system_inject.mjs` 复用项目运行中的 HTTP 接口：预检和回采走 `/api/training-inject/proxy`，完整写入走 `/api/training-inject`（regex解析、原有节点创建/编辑与连线/评分流程）。默认关闭封面、背景图和数字人生成，避免把生成资源耗时混入配置写入。随后经系统代理保留完整 DTO 关闭业务卡片跳过开关，并再次回采。

系统注入以 SSE 提供进度；中断后先读取目标，不能将整份 replace 自动当作续跑。`system-target-backup.json`、`system-injection-events.json`、`system-target-readback.json`、`system-verification.json` 保存实际调用证据，不含凭证。401意味着登录配置未通过校验，节点数量未知，不是空任务。项目 `.env` 的 AUTHORIZATION、COOKIE 与浏览器中的登录态是两份配置，须使用当前有效值。

## 平台接口形状（系统内部及直连备用）

依据 Agent_Evaluation 的 `frontend/lib/training-injector/api.ts`、`parser.ts` 和 `frontend/lib/training-refiner/injector.ts` 的能力训练接口形状编写，适配观察日期 2026-10-27；平台后续变化需重新读接口响应验证。

- 默认 API root：`https://cloudapi.polymas.com`，服务路径 `/teacher-course/abilityTrain/`。
- 完整链接读取 `trainTaskId`、`courseId`/`businessId`、`libraryFolderId`/`libraryId`；courseId 也可取 `/agent-course-full/{courseId}/`。仅处理能力训练，不套用于口语/Pro。
- 学校专属域名需显式给 `--api-root https://学校域名/cloud`；禁止将登录凭证自动发往随意解析出的域名。正式地址使用 HTTPS，测试仅允许本机 HTTP。
- 查询：`queryScriptStepList`（带 trainSubType=ability）、`queryScriptStepFlowList`、`queryScoreItemList`。响应 code=200 或 success=true，data 为列表；异常按失败处理，不能当作空任务。
- 节点：先 `createScriptStep`，再 `editScriptStep` 完整补齐。由客户端生成 stepId。完整字段包含 `historyRecordNum=-1`、`isSkipStep=0`、`endStrategy=2`、`interactiveRounds`、`trainerName`、`prologue`、`llmPrompt`。endStrategy=2 继承当前项目默认，并非已验证的硬门控模式。
- 连线：`createScriptStepFlow`，客户端生成 flowId，使用 source-bottom/target-top handles、flowSettingType=quick、flowCondition、flowConfiguration、transitionPrompt、transitionHistoryNum=-1。所有出边 `isDefault=0`，仅 START 唯一入口为 1，避免把条件边当默认兜底；需在实际平台验证条件边触发行为。
- 评分：`createScoreItem`，通过 `queryScoreItemList` 回采核对名称、分值和要求。接口由服务端分配 itemId；网络超时后先按内容回采，名称碰撞即停止。
- 空任务应先打开一次平台工作流编辑页，使 START/END 初始化。已有业务节点时停止；空任务 START→END 连线在配置创建并校验后才删除，START 入口最后连接。
- 脚本不修改任务名称、封面、数字人资源，不上传附件。默认沿用项目已有的语音参数并关闭形象显示，可通过 `POLYMAS_AGENT_ID`、`POLYMAS_AGENT_VOICE_ID`、`POLYMAS_MODEL_ID` 指定学校实际可用参数。需要图像、附件、数字人时由 agent 使用目标平台支持的资源接口单独处理，纳入资源回采。
- 本地只保存配置、节点 ID、目标快照和操作状态。日志不记录 Cookie 或 Authorization。

验收至少覆盖：跨节点角色是否保留；小结是否逐字显示且先于下一轮线索；公共任务不合格、角色题漏答时是否留在当前环节；选做放弃是否继续；达到轮次上限是否意外放行；四角色问题全景是否在训练结束后出现；评分是否依据真实对话。结构回采只证明配置已存入，学生端行为必须另测。
