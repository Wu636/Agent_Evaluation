"""Offline contract tests with a local fake platform. No real account is used."""
import contextlib
import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch
from types import SimpleNamespace

spec = importlib.util.spec_from_file_location("pipeline", Path(__file__).with_name("pipeline.py"))
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)


class FakePlatform(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_POST(self):
        payload = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        api = self.path.rsplit("/", 1)[-1]
        state = self.server.state
        state["calls"].append(api)
        if api == "queryScriptStepList":
            value = state["nodes"]
        elif api == "queryScriptStepFlowList":
            value = state["flows"]
        elif api == "queryScoreItemList":
            value = state["scores"]
        elif api == "createScriptStep":
            if any(n["stepId"] == payload["stepId"] for n in state["nodes"]):
                self.send_error(409)
                return
            state["nodes"].append(payload)
            value = payload["stepId"]
        elif api == "editScriptStep":
            node = next(n for n in state["nodes"] if n["stepId"] == payload["stepId"])
            node.update(payload)
            value = True
        elif api == "createScriptStepFlow":
            state["flows"].append(payload)
            value = True
        elif api == "delScriptStepFlow":
            state["flows"][:] = [f for f in state["flows"] if f["flowId"] != payload["flowId"]]
            value = True
        elif api == "createScoreItem":
            state["scores"].append({**payload, "itemId": "score1"})
            value = {"itemId": "score1"}
        else:
            self.send_error(404)
            return
        if state.get("lose_response_once") == api:
            state["lose_response_once"] = None
            # Mutation succeeded, but caller observes a failed response.
            self.send_error(504)
            return
        if state.get("malformed_query") == api:
            value = {"unexpected": "shape"}
        raw = json.dumps({"code": 200, "data": value}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "bundle"
        source = Path(self.tmp.name) / "source.txt"
        source.write_text("必须显示原文小结。\n" + "很长的教师文档\n" * 2300 + "最后必须复盘。")
        p.initialize(source, self.root)
        m = p.read(self.root / "manifest.json")
        m.update(taskName="测试案例", audience="学生", description="测试", sharedPrompt="你是导师，按阶段引导。",
            stageFiles=["stages/01.json"], edges=[{"from": "START", "to": "ONE", "condition": ""},
            {"from": "ONE", "to": "END", "condition": "TASK_COMPLETE", "transitionPrompt": "结束"}],
            requirements=[{"id": "R1", "quote": "原文小结", "checks": [{"stage": "ONE", "field": "prologue", "contains": "原文小结"}]}])
        p.save(self.root / "manifest.json", m)
        p.save(self.root / "stages/01.json", {"id": "ONE", "name": "结束小结", "teacherPhase": 1, "kind": "summary",
            "trainerName": "导师", "description": "输出小结", "prologue": "原文小结", "prompt": "确认已看完时只输出 TASK_COMPLETE",
            "rounds": 30, "literalSummary": "原文小结", "futureForbidden": ["尚未公开线索"]})
        p.save(self.root / "rubric.json", [{"itemName": "维度", "score": 100, "description": "维度描述", "requireDetail": "根据真实回答评价",
            "children": [{"name": "得分点", "score": 100, "requirement": "真实证据"}]}])
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), FakePlatform)
        self.server.state = {"nodes": [{"stepId": "start", "stepDetailDTO": {"nodeType": "SCRIPT_START"}},
            {"stepId": "end", "stepDetailDTO": {"nodeType": "SCRIPT_END"}}],
            "flows": [{"flowId": "empty", "scriptStepStartId": "start", "scriptStepEndId": "end", "flowCondition": ""}],
            "scores": [], "calls": []}
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.env = patch.dict(os.environ, {"POLYMAS_AUTHORIZATION": "fixture-token", "POLYMAS_COOKIE": "fixture-cookie"})
        self.env.start()

    def tearDown(self):
        self.env.stop()
        self.server.shutdown()
        self.server.server_close()
        self.tmp.cleanup()

    def args(self, command="apply"):
        return SimpleNamespace(command=command, bundle=str(self.root), target="fixture", course_id="course", library_id="library",
            api_root=f"http://127.0.0.1:{self.server.server_port}", timeout=2)

    def run_action(self, command="apply"):
        with contextlib.redirect_stdout(io.StringIO()):
            return p.platform_action(self.args(command))

    def test_long_source_reassembles_including_tail(self):
        index = p.read(self.root / "source-map.json")
        parts = "".join((self.root / part["file"]).read_text() for part in index["parts"])
        self.assertEqual(parts, (self.root / "source.txt").read_text())
        self.assertTrue(parts.endswith("最后必须复盘。"))
        self.assertGreater(len(index["parts"]), 1)

    def test_lost_create_response_resumes_without_duplicate(self):
        self.server.state["lose_response_once"] = "createScriptStep"
        with self.assertRaises(RuntimeError):
            self.run_action()
        self.assertTrue((self.root / "injection-state.json").exists())
        self.assertTrue(self.run_action()["verified"])
        self.assertEqual(self.server.state["calls"].count("createScriptStep"), 1)
        self.assertTrue(self.run_action()["verified"])
        self.assertEqual(len(self.server.state["nodes"]), 3)
        self.assertEqual(len(self.server.state["flows"]), 2)
        self.assertEqual(len(self.server.state["scores"]), 1)
        self.assertTrue(self.run_action("verify")["verified"])

    def test_lost_score_response_reconciles_by_content(self):
        self.server.state["lose_response_once"] = "createScoreItem"
        with self.assertRaises(RuntimeError):
            self.run_action()
        self.assertTrue(self.run_action()["verified"])
        self.assertEqual(self.server.state["calls"].count("createScoreItem"), 1)

    def test_readback_detects_silent_truncation(self):
        self.run_action()
        self.server.state["nodes"][-1]["stepDetailDTO"]["llmPrompt"] = "被平台截断"
        with self.assertRaises(ValueError):
            self.run_action("verify")
        report = p.read(self.root / "verification.json")
        self.assertFalse(report["verified"])
        self.assertTrue(any("llmPrompt" in x for x in report["errors"]))

    def test_existing_target_and_bad_query_stop_before_mutation(self):
        self.server.state["nodes"].append({"stepId": "existing", "stepDetailDTO": {"nodeType": "SCRIPT_NODE"}})
        with self.assertRaises(ValueError):
            self.run_action()
        self.assertFalse(any(x.startswith(("create", "edit", "del")) for x in self.server.state["calls"]))
        self.server.state["nodes"].pop()
        self.server.state["malformed_query"] = "queryScriptStepList"
        with self.assertRaises(RuntimeError):
            self.run_action()
        self.assertFalse(any(x.startswith(("create", "edit", "del")) for x in self.server.state["calls"]))

    def test_content_review_and_hash_change_block_apply(self):
        p.save(self.root / "review-issues.json", [{"id": "MED", "status": "open", "issue": "教师内容待核对"}])
        self.assertTrue(self.run_action("prepare")["readOnly"])
        with self.assertRaises(ValueError):
            self.run_action()
        p.save(self.root / "review-issues.json", [])
        self.run_action()
        stage = p.read(self.root / "stages/01.json")
        stage["description"] = "已更改"
        p.save(self.root / "stages/01.json", stage)
        before = len(self.server.state["calls"])
        with self.assertRaises(ValueError):
            self.run_action()
        self.assertEqual(len(self.server.state["calls"]), before)

    def test_validation_finds_missing_summary_future_leak_unreachable_and_bad_score(self):
        self.assertTrue(p.validate(self.root)["valid"])
        stage = p.read(self.root / "stages/01.json")
        stage.update(prologue="被改写的小结", prompt="尚未公开线索 TASK_COMPLETE")
        p.save(self.root / "stages/01.json", stage)
        m = p.read(self.root / "manifest.json")
        m["edges"] = [{"from": "START", "to": "ONE", "condition": ""}]
        p.save(self.root / "manifest.json", m)
        scores = p.read(self.root / "rubric.json")
        scores[0]["children"][0]["score"] = 99
        p.save(self.root / "rubric.json", scores)
        errors = p.validate(self.root)["errors"]
        self.assertTrue(any("原文小结" in x for x in errors))
        self.assertTrue(any("后续线索" in x for x in errors))
        self.assertTrue(any("结束路径" in x for x in errors))
        self.assertTrue(any("子项合计" in x for x in errors))


if __name__ == "__main__":
    unittest.main(verbosity=2)
